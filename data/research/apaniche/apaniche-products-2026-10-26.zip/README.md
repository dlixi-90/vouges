# Dữ liệu sản phẩm công khai của Apaniche

Nguồn: [apaniche.vn](https://apaniche.vn/), [API sản phẩm công khai](https://apaniche.vn/wp-json/wc/store/v1/products?per_page=1) và các URL chi tiết sản phẩm. Thời điểm lấy từng bản ghi nằm trong dữ liệu; số lượng và độ phủ mới nhất nằm trong [collection-summary.json](./collection-summary.json).

## Các tệp sử dụng

| Tệp | Nội dung |
| --- | --- |
| [products.json](./products.json) | Toàn bộ sản phẩm: thông tin API, ảnh, đặc tính, các biến thể và đánh giá hiển thị |
| [products.csv](./products.csv) | Bảng sản phẩm tổng hợp, mở bằng Excel hoặc phần mềm bảng tính |
| [variants.json](./variants.json) | Mỗi dòng là một biến thể/dung tích có dữ liệu chi tiết |
| [variants.csv](./variants.csv) | Giá, trạng thái bán và ảnh của từng biến thể |
| [assessments.csv](./assessments.csv) | Dữ liệu lưu/tỏa hương, mùa/ngày–đêm, nhóm mùi và tầng hương |
| [collection-summary.json](./collection-summary.json) | Độ phủ, các trường còn thiếu và lỗi thu thập |
| [quality-report.json](./quality-report.json) | Kiểm tra tính nhất quán sau thu thập |

Các tệp `catalog-base.json`, `product-details.jsonl` và `progress.json` là dữ liệu trung gian để kiểm tra và tiếp tục khi gián đoạn. `product-details.jsonl` có thể có nhiều lần lấy cho cùng một sản phẩm; các tệp xuất tổng hợp chỉ sử dụng bản ghi cuối cùng theo ID.

## Ý nghĩa và đơn vị

- `sourceId` là ID của Apaniche, không phải ID MongoDB của Velours.
- `price`, `regularPrice`, `salePrice`, `priceRange` và giá trong biến thể là tiền theo `currency`. Nguồn hiện dùng **VND: 1.250.000 đồng được lưu thành 1250000**. Velours hiện lưu giá bằng nghìn đồng, nên không được nhập trực tiếp mà chưa chuyển đơn vị.
- Giá cấp sản phẩm và giá theo dung tích đều được giữ nguyên từ nguồn tương ứng. Nếu giá biến thể khác khoảng giá của API, báo cáo chất lượng ghi nhận thay vì tự sửa.
- `inStock` chỉ là trạng thái còn hàng công khai, không phải số lượng tồn kho.
- `maxPurchaseQuantity` là giới hạn mua được nguồn hiển thị, không suy ra số lượng thực trong kho.
- `images[].url` là liên kết ảnh chung. `variants[].imageUrl` là ảnh biến thể; các size có thể dùng chung một URL.
- `variantSupplements` chứa biến thể được API danh mục liệt kê nhưng thiếu chi tiết trong HTML; đã bổ sung qua API công khai và giữ nguồn/thời gian riêng. Tệp `variants.json/csv` gộp cả phần này. Giá 0 từ nguồn được đánh dấu, không khẳng định đây là hàng miễn phí.
- `specifications` giữ tên thuộc tính và giá trị: hãng, xuất xứ, đối tượng, nhóm hương, nồng độ và các thuộc tính khác khi có.
- `scentNotes.top/middle/base` là các tầng hương được trang nguồn trình bày bằng dữ liệu có cấu trúc.
- `longevity` và `sillage` lưu `displayedCount` và `displayedPercent` đúng như biểu đồ nguồn. Chưa xác minh các con số có phải bình chọn thật hoặc được tổng hợp theo phương pháp nào.
- Khi số đếm nguồn là số âm, giữ ở `sourceRawCount`, đánh dấu `sourceCountIssue` và để `displayedCount = null`. Tương tự, phần trăm ngoài khoảng hợp lệ được giữ ở `sourceRawPercent` thay vì tự sửa số nguồn.
- `suitability[].displayedPercent` là chiều dài thanh Xuân/Hạ/Thu/Đông/Đêm/Ngày trên nguồn, không phải tỷ lệ hiệu quả đo thực nghiệm. Các mục không nhất thiết cộng thành 100%.
- Một số trang nguồn có giá trị phần trăm lớn hơn 100. Với các mục này, `sourceRawPercent` giữ nguyên số nguồn, `sourceValueIssue` đánh dấu bất thường và `displayedPercent` để `null`; không tự sửa thành 100 hoặc suy đoán số đúng.
- `assessmentProvenance.originalAssessmentSource = null` và `methodologyVerified = false` thể hiện chưa kiểm chứng được nguồn gốc/phương pháp của chỉ số.
- `null`, mảng trống hoặc trường không có nghĩa là nguồn chưa cung cấp hoặc chưa trích xuất được; không tự quy thành 0.
- `detailStatus` phân biệt `ok`, `error` và `pending`. Có `ok` không có nghĩa mọi trường đều hiện diện: một số mặt hàng không phải nước hoa hoặc chưa có biểu đồ/tầng hương.

## Phương pháp

1. Đọc robots và danh mục công khai qua Store API, phân trang theo ID ổn định, loại các bài mô tả dài khỏi trường dữ liệu yêu cầu.
2. Đọc trang chi tiết với hai yêu cầu đồng thời, giãn lượt bắt đầu tối thiểu 300 ms và lưu tiến độ.
3. Khi có mục đánh giá khách hàng, kết thúc đọc trước phần đó để tránh thu thập bình luận, thông tin người viết và phần điều hướng toàn site.
4. Chỉ trích xuất thuộc tính sản phẩm, số liệu hiển thị và URL ảnh. Không tải hàng loạt tệp ảnh hoặc sao chép nguyên bài giới thiệu/review.
5. Dừng khi có phản hồi từ chối truy cập; khi bị giới hạn tần suất, chờ theo phản hồi trước khi thử lại. Không sử dụng tài khoản, cookie đăng nhập hoặc đường dẫn quản trị.

## Chạy lại

Chạy từ thư mục gốc repository:

```powershell
# Tiếp tục những sản phẩm chưa có chi tiết
node tools/apaniche/collect-products.mjs

# Thử lại các trang từng gặp lỗi
node tools/apaniche/collect-products.mjs --retry-errors

# Chỉ xuất lại dữ liệu đã có
node tools/apaniche/collect-products.mjs --phase=export

# Kiểm tra dữ liệu tổng hợp
node tools/apaniche/validate-products.mjs

# Kiểm tra bộ trích xuất bằng dữ liệu giả lập
node --test tools/apaniche/product-parser.test.mjs
```

Dữ liệu nằm trong thư mục nghiên cứu, **chưa được nhập vào database hoặc thay thế catalog của Velours**. Toàn bộ giá và trạng thái là ảnh chụp dữ liệu ở thời điểm thu thập, không đảm bảo giữ nguyên sau đó.
